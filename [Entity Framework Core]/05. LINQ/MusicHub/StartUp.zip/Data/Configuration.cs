﻿namespace MusicHub.Data;

public static class Configuration
{
    public static string ConnectionString =
        @"Server=(localdb)\LocalHost;Database=MusicHub;Trusted_Connection=True";
}
