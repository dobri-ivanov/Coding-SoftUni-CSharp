﻿using ProductShop.Models;

namespace ProductShop.DTOs.Import;

public class ImportCategoriesProductsDTO
{
    public int CategoryId { get; set; }
    public int ProductId { get; set; }
}
