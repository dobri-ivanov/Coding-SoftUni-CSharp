﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-TQCFNM7\LOCALSERVER;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
