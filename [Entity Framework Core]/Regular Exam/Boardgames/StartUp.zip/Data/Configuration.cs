﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\LocalHost;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
