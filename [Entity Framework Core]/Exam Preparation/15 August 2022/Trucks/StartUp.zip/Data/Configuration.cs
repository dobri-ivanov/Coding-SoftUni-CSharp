﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\LocalHost;Database=Trucks;Trusted_Connection=True";
    }
}