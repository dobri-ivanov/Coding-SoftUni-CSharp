﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\LocalHost;Database=Theatre;Integrated Security=True;Encrypt=False";
    }
}
