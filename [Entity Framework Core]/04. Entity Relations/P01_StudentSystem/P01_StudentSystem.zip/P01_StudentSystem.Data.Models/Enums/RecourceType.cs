﻿namespace P01_StudentSystem.Data.Models.Enums;

public enum RecourceType
{
    Video,
    Presentation,
    Document,
    Other
}
