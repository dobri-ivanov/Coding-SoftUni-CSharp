﻿namespace P01_StudentSystem.Data.Models.Enums;

public enum ContentTypes
{
    Application,
    Pdf,
    Zip
}
