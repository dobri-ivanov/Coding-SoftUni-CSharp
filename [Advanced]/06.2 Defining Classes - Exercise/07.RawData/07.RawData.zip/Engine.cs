﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.RawData
{
    public class Engine
    {
        private int speed;
        private int power;

        public int Power { get; set; }
        public int Speed { get; set; }
    }
}
