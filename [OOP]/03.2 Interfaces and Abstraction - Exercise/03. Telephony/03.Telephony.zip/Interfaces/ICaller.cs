﻿

namespace PersonInfo.Interfaces
{
    public interface ICaller
    {
        void Call(string number);
    }
}
