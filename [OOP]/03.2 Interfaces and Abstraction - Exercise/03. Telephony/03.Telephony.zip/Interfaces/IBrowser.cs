﻿

namespace PersonInfo.Interfaces
{
    public interface IBrowser
    {
        void Browse(string site);
    }
}
