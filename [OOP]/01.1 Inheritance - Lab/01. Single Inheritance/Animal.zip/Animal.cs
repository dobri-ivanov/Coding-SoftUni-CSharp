﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01._Single_Inheritance
{
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
