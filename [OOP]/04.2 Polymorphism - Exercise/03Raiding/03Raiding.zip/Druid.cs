﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03Raiding
{
    public class Druid : BaseHero
    {
        public Druid(string name) : base(name)
        {
        }
    }
}
