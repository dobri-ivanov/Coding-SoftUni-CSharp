﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04._Wild_Farm
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity)
        { }
    }
}
