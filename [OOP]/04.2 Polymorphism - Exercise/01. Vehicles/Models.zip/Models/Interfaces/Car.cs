﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01._Vehicles.Models.Interfaces
{
    public class Car : IDrivable
    {
        public Car(double fuelQuantitiy, double fuelConsumptionPerKilometer)
        {
            FuelQuantitiy = fuelQuantitiy;
            FuelConsumptionPerKilometer = fuelConsumptionPerKilometer + 0.9;
        }

        public double FuelQuantitiy { get; set; }
        public double FuelConsumptionPerKilometer { get; set; }

        public string Drive(double kilometers)
        {
            if (FuelQuantitiy >= kilometers * FuelConsumptionPerKilometer)
            {
                this.FuelQuantitiy-= kilometers * FuelConsumptionPerKilometer;
                return $"Car travelled {kilometers} km";
            }
            return "Car needs refueling";
        }

        public void Refuel(double fuel)
        {
            this.FuelQuantitiy += fuel;
        }

        public override string ToString()
        {
            return $"Car: {this.FuelQuantitiy:f2}";
        }
    }
}
