﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01._Vehicles.Models.Interfaces
{
    internal class Truck : IDrivable
    {
        public Truck(double fuelQuantitiy, double fuelConsumptionPerKilometer)
        {
            FuelQuantitiy = fuelQuantitiy;
            FuelConsumptionPerKilometer = fuelConsumptionPerKilometer + 1.6;
        }

        public double FuelQuantitiy { get; set; }
        public double FuelConsumptionPerKilometer { get; set; }

        public string Drive(double kilometers)
        {
            if (FuelQuantitiy >= kilometers * FuelConsumptionPerKilometer)
            {
                FuelQuantitiy -= kilometers * FuelConsumptionPerKilometer;
                return $"Truck travelled {kilometers} km";
            }
            return "Truck needs refueling";
        }

        public void Refuel(double fuel)
        {
            double fuelToBeFilled = fuel * 0.95;
            this.FuelQuantitiy += fuelToBeFilled;
        }

        public override string ToString()
        {
            return $"Truck: {this.FuelQuantitiy:f2}";
        }
    }
}
