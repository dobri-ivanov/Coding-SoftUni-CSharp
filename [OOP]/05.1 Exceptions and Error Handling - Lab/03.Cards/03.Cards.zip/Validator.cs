﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;

namespace _03.Cards
{
    internal static class Validator
    {
        public static void ValidateCard(string face, string suit)
        {
            List<string> possibleFaces = new List<string>() { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
            if (!possibleFaces.Any(c => c == face)) 
            {
                throw new ArgumentException("Invalid card!");
            }

            List<string> possibleSuits = new List<string>() { "S", "H", "D", "C"};
            if (!possibleSuits.Any(c => c == suit))
            {
                throw new ArgumentException("Invalid card!");
            }
        }
    }
}
