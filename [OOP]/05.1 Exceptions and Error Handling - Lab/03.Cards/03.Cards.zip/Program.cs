﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _03.Cards
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Card> cards = new List<Card>();
            string[] cardTokens = Console.ReadLine().Split(", ", StringSplitOptions.RemoveEmptyEntries);
            
            for (int i = 0; i < cardTokens.Length; i++)
            {
                string face = cardTokens[i].Split(" ", StringSplitOptions.RemoveEmptyEntries).First();
                string suit = cardTokens[i].Split(" ", StringSplitOptions.RemoveEmptyEntries).Skip(1).First();

                try
                {
                    Validator.ValidateCard(face, suit);
                    Card card = new Card(face, suit);
                    cards.Add(card);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            Console.WriteLine(String.Join(" ", cards));
        }
    }
}
