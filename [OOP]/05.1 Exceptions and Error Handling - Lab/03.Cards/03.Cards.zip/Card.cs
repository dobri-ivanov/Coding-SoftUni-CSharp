﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Cards
{
    public class Card
    {
        public Card(string face, string suit)
        {
            Face = face;
            Suit = GetSuit(suit);
        }

        public string Face { get; set; }
        public string Suit { get; set; }

        public override string ToString()
        {
            return $"[{Face}{Suit}]";
        }

        public string GetSuit(string suit)
        {
            if (suit == "S") return "\u2660";
            if (suit == "H") return "\u2665";
            if (suit == "D") return "\u2666";
            if (suit == "C") return "\u2663";
            return null;
        }
    }
}
