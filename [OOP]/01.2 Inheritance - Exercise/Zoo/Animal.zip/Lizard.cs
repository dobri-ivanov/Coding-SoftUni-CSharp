﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Zoo
{
    public class Lizard : Reptile
    {
        public Lizard(string name) : base(name)
        {
        }
    }
}
