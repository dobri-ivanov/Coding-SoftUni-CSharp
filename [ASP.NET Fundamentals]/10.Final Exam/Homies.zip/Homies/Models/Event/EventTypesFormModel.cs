﻿namespace Homies.Models.Event
{
    public class EventTypesFormModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
